<?php
// Iniciar sesión para manejar autenticación
session_start();

// Verificar si el usuario está logueado como administrador
if (!isset($_SESSION['admin_logueado']) || $_SESSION['admin_logueado'] !== true) {
    header('Location: login.php');
    exit;
}

// Incluir archivos necesarios
require_once(__DIR__ . '/controllers/ReservaControllers.php');

// Instanciar el controlador
$controlador = new ReservaControllers();

// Procesar acciones AJAX si es necesario
if (isset($_POST['ajax_action'])) {
    $response = ['success' => false, 'message' => ''];
    
    switch ($_POST['ajax_action']) {
        case 'cambiar_estado':
            $id_reserva = (int)$_POST['id_reserva'];
            $nuevo_estado = $_POST['nuevo_estado'];
            if ($controlador->actualizarEstadoReserva($id_reserva, $nuevo_estado)) {
                $response = ['success' => true, 'message' => 'Estado actualizado correctamente'];
            } else {
                $response = ['success' => false, 'message' => 'Error al actualizar el estado'];
            }
            break;
            
        case 'asociar_pago':
            $id_reserva = (int)$_POST['id_reserva'];
            $id_pago = (int)$_POST['id_pago'];
            if ($controlador->asociarPagoReserva($id_reserva, $id_pago)) {
                $response = ['success' => true, 'message' => 'Pago asociado correctamente'];
            } else {
                $response = ['success' => false, 'message' => 'Error al asociar el pago'];
            }
            break;
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Obtener todas las reservas
$reservas = $controlador->obtenerTodasReservas();

// Obtener todos los pagos no asociados
$pagos_pendientes = $controlador->obtenerPagosPendientes();

// Procesar formulario de nueva reserva manual
$mensaje = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['accion']) && $_POST['accion'] == 'crear_reserva') {
        $nombre = trim($_POST['nombre']);
        $telefono = trim($_POST['telefono']);
        $email = trim($_POST['email']);
        $fecha = $_POST['fecha'];
        $hora = $_POST['hora'];
        $personas = (int)$_POST['personas'];
        $menu_tipo = $_POST['menu_tipo'];
        $estado = $_POST['estado'];
        $precio_total = (float)$_POST['precio_total'];
        $info_adicional = trim($_POST['info_adicional']);
        
        // Validar datos
        if (empty($nombre)) {
            $error = "El nombre es obligatorio";
        } elseif (empty($telefono) || !preg_match('/^9\d{8}$/', $telefono)) {
            $error = "El teléfono debe tener 9 dígitos y comenzar con 9";
        } elseif (empty($fecha)) {
            $error = "La fecha es obligatoria";
        } elseif (empty($hora)) {
            $error = "La hora es obligatoria";
        } elseif ($personas < 1) {
            $error = "El número de personas debe ser al menos 1";
        } elseif (empty($menu_tipo)) {
            $error = "Debe seleccionar un tipo de menú";
        } elseif (empty($estado)) {
            $error = "Debe seleccionar un estado";
        } elseif ($precio_total <= 0) {
            $error = "El precio total debe ser mayor que cero";
        } else {
            // Crear la reserva
            $resultado = $controlador->crearReserva(
                $nombre, 
                $telefono, 
                $email, 
                $fecha, 
                $hora, 
                $personas, 
                $menu_tipo, 
                $estado, 
                $precio_total, 
                $info_adicional
            );
            
            if ($resultado) {
                $mensaje = "Reserva creada correctamente";
                // Recargar las reservas
                $reservas = $controlador->obtenerTodasReservas();
            } else {
                $error = "Error al crear la reserva";
            }
        }
    }
    
    if (isset($_POST['accion']) && $_POST['accion'] == 'editar_reserva') {
        $id_reserva = (int)$_POST['id_reserva'];
        $nombre = trim($_POST['nombre']);
        $telefono = trim($_POST['telefono']);
        $email = trim($_POST['email']);
        $fecha = $_POST['fecha'];
        $hora = $_POST['hora'];
        $personas = (int)$_POST['personas'];
        $menu_tipo = $_POST['menu_tipo'];
        $estado = $_POST['estado'];
        $precio_total = (float)$_POST['precio_total'];
        $info_adicional = trim($_POST['info_adicional']);
        
        // Validar datos (similar a la creación)
        if (empty($nombre)) {
            $error = "El nombre es obligatorio";
        } elseif (empty($telefono) || !preg_match('/^9\d{8}$/', $telefono)) {
            $error = "El teléfono debe tener 9 dígitos y comenzar con 9";
        } elseif (empty($fecha)) {
            $error = "La fecha es obligatoria";
        } elseif (empty($hora)) {
            $error = "La hora es obligatoria";
        } elseif ($personas < 1) {
            $error = "El número de personas debe ser al menos 1";
        } elseif (empty($menu_tipo)) {
            $error = "Debe seleccionar un tipo de menú";
        } elseif (empty($estado)) {
            $error = "Debe seleccionar un estado";
        } elseif ($precio_total <= 0) {
            $error = "El precio total debe ser mayor que cero";
        } else {
            // Actualizar la reserva
            $resultado = $controlador->actualizarReserva(
                $id_reserva,
                $nombre, 
                $telefono, 
                $email, 
                $fecha, 
                $hora, 
                $personas, 
                $menu_tipo, 
                $estado, 
                $precio_total, 
                $info_adicional
            );
            
            if ($resultado) {
                $mensaje = "Reserva actualizada correctamente";
                // Recargar las reservas
                $reservas = $controlador->obtenerTodasReservas();
            } else {
                $error = "Error al actualizar la reserva";
            }
        }
    }
}

// Incluir el encabezado
include('includes/header.php');
?>

<!-- Enlazar archivos CSS -->
<link rel="stylesheet" href="assets/css/admin.css">

<main class="main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="page-title">Administración de Reservas</h1>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($mensaje)): ?>
                    <div class="alert alert-success">
                        <?php echo $mensaje; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Botón para crear nueva reserva -->
                <div class="mb-4">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalNuevaReserva">
                        <i class="fas fa-plus-circle"></i> Nueva Reserva
                    </button>
                </div>
                
                <!-- Filtros de búsqueda -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title">Filtros de búsqueda</h5>
                    </div>
                    <div class="card-body">
                        <form id="filtroForm" class="row g-3">
                            <div class="col-md-3">
                                <label for="filtroFecha" class="form-label">Fecha</label>
                                <input type="date" class="form-control" id="filtroFecha">
                            </div>
                            <div class="col-md-3">
                                <label for="filtroEstado" class="form-label">Estado</label>
                                <select class="form-select" id="filtroEstado">
                                    <option value="">Todos</option>
                                    <option value="Pendiente">Pendiente</option>
                                    <option value="Confirmado">Confirmado</option>
                                    <option value="Pagado">Pagado</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="filtroTelefono" class="form-label">Teléfono</label>
                                <input type="text" class="form-control" id="filtroTelefono" placeholder="Número de teléfono">
                            </div>
                            <div class="col-md-3 d-flex align-items-end">
                                <button type="button" id="btnFiltrar" class="btn btn-primary me-2">Filtrar</button>
                                <button type="button" id="btnLimpiarFiltros" class="btn btn-outline-secondary">Limpiar</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Tabla de reservas -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Listado de Reservas</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="tablaReservas">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Nombre</th>
                                        <th>Teléfono</th>
                                        <th>Fecha</th>
                                        <th>Hora</th>
                                        <th>Personas</th>
                                        <th>Menú</th>
                                        <th>Total</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($reservas as $reserva): ?>
                                    <tr data-id="<?php echo $reserva['id_reserva']; ?>" class="fila-reserva">
                                        <td><?php echo $reserva['id_reserva']; ?></td>
                                        <td><?php echo htmlspecialchars($reserva['nombre']); ?></td>
                                        <td><?php echo htmlspecialchars($reserva['telefono']); ?></td>
                                        <td><?php echo date('d/m/Y', strtotime($reserva['fecha_reserva'])); ?></td>
                                        <td><?php echo date('H:i', strtotime($reserva['hora_reserva'])); ?></td>
                                        <td><?php echo $reserva['cantidad_personas']; ?></td>
                                        <td><?php echo htmlspecialchars($reserva['tipo_menu']); ?></td>
                                        <td>S/ <?php echo number_format($reserva['total'], 2); ?></td>
                                        <td>
                                            <span class="badge <?php 
                                                echo $reserva['estado'] == 'Pendiente' ? 'bg-warning' : 
                                                    ($reserva['estado'] == 'Confirmado' ? 'bg-info' : 
                                                        ($reserva['estado'] == 'Pagado' ? 'bg-success' : 'bg-secondary')); 
                                            ?>">
                                                <?php echo htmlspecialchars($reserva['estado']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <button type="button" class="btn btn-info btn-ver-detalles" data-id="<?php echo $reserva['id_reserva']; ?>">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button type="button" class="btn btn-primary btn-editar" data-id="<?php echo $reserva['id_reserva']; ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button type="button" class="btn btn-success btn-cambiar-estado" data-id="<?php echo $reserva['id_reserva']; ?>" data-estado="<?php echo $reserva['estado']; ?>">
                                                    <i class="fas fa-exchange-alt"></i>
                                                </button>
                                                <?php if ($reserva['estado'] != 'Pagado'): ?>
                                                <button type="button" class="btn btn-warning btn-asociar-pago" data-id="<?php echo $reserva['id_reserva']; ?>">
                                                    <i class="fas fa-money-bill"></i>
                                                </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Modal para Nueva Reserva -->
<div class="modal fade" id="modalNuevaReserva" tabindex="-1" aria-labelledby="modalNuevaReservaLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalNuevaReservaLabel">Nueva Reserva</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formNuevaReserva" method="post" action="">
                    <input type="hidden" name="accion" value="crear_reserva">
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="nombre" class="form-label">Nombre <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="nombre" name="nombre" required>
                        </div>
                        <div class="col-md-6">
                            <label for="telefono" class="form-label">Teléfono <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="telefono" name="telefono" pattern="9[0-9]{8}" title="Debe ser un número de 9 dígitos que comience con 9" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="fecha" class="form-label">Fecha <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="fecha" name="fecha" required>
                        </div>
                        <div class="col-md-6">
                            <label for="hora" class="form-label">Hora <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" id="hora" name="hora" required>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="personas" class="form-label">Personas <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="personas" name="personas" min="1" value="1" required>
                        </div>
                        <div class="col-md-6">
                            <label for="menu_tipo" class="form-label">Tipo de Menú <span class="text-danger">*</span></label>
                            <select class="form-select" id="menu_tipo" name="menu_tipo" required>
                                <option value="">Seleccione...</option>
                                <option value="desayuno">Desayuno</option>
                                <option value="almuerzo">Almuerzo</option>
                                <option value="cena">Cena</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="estado" class="form-label">Estado <span class="text-danger">*</span></label>
                            <select class="form-select" id="estado" name="estado" required>
                                <option value="Pendiente">Pendiente</option>
                                <option value="Confirmado">Confirmado</option>
                                <option value="Pagado">Pagado</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="precio_total" class="form-label">Precio Total <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">S/</span>
                                <input type="number" class="form-control" id="precio_total" name="precio_total" min="0" step="0.01" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="info_adicional" class="form-label">Información Adicional</label>
                        <textarea class="form-control" id="info_adicional" name="info_adicional" rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" form="formNuevaReserva" class="btn btn-primary">Guardar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal para Editar Reserva -->
<div class="modal fade" id="modalEditarReserva" tabindex="-1" aria-labelledby="modalEditarReservaLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalEditarReservaLabel">Editar Reserva</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formEditarReserva" method="post" action="">
                    <input type="hidden" name="accion" value="editar_reserva">
                    <input type="hidden" name="id_reserva" id="editar_id_reserva">
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="editar_nombre" class="form-label">Nombre <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editar_nombre" name="nombre" required>
                        </div>
                        <div class="col-md-6">
                            <label for="editar_telefono" class="form-label">Teléfono <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editar_telefono" name="telefono" pattern="9[0-9]{8}" title="Debe ser un número de 9 dígitos que comience con 9" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="editar_email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="editar_email" name="email">
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="editar_fecha" class="form-label">Fecha <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="editar_fecha" name="fecha" required>
                        </div>
                        <div class="col-md-6">
                            <label for="editar_hora" class="form-label">Hora <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" id="editar_hora" name="hora" required>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="editar_personas" class="form-label">Personas <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="editar_personas" name="personas" min="1" required>
                        </div>
                        <div class="col-md-6">
                            <label for="editar_menu_tipo" class="form-label">Tipo de Menú <span class="text-danger">*</span></label>
                            <select class="form-select" id="editar_menu_tipo" name="menu_tipo" required>
                                <option value="">Seleccione...</option>
                                <option value="desayuno">Desayuno</option>
                                <option value="almuerzo">Almuerzo</option>
                                <option value="cena">Cena</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="editar_estado" class="form-label">Estado <span class="text-danger">*</span></label>
                            <select class="form-select" id="editar_estado" name="estado" required>
                                <option value="Pendiente">Pendiente</option>
                                <option value="Confirmado">Confirmado</option>
                                <option value="Pagado">Pagado</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="editar_precio_total" class="form-label">Precio Total <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">S/</span>
                                <input type="number" class="form-control" id="editar_precio_total" name="precio_total" min="0" step="0.01" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="editar_info_adicional" class="form-label">Información Adicional</label>
                        <textarea class="form-control" id="editar_info_adicional" name="info_adicional" rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" form="formEditarReserva" class="btn btn-primary">Guardar Cambios</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal para Ver Detalles de Reserva -->
<div class="modal fade" id="modalDetallesReserva" tabindex="-1" aria-labelledby="modalDetallesReservaLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalDetallesReservaLabel">Detalles de la Reserva</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="fw-bold">Información del Cliente</h6>
                        <p><strong>Nombre:</strong> <span id="detalle_nombre"></span></p>
                        <p><strong>Teléfono:</strong> <span id="detalle_telefono"></span></p>
                        <p><strong>Email:</strong> <span id="detalle_email"></span></p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="fw-bold">Información de la Reserva</h6>
                        <p><strong>Fecha:</strong> <span id="detalle_fecha"></span></p>
                        <p><strong>Hora:</strong> <span id="detalle_hora"></span></p>
                        <p><strong>Personas:</strong> <span id="detalle_personas"></span></p>
                        <p><strong>Tipo de Menú:</strong> <span id="detalle_menu_tipo"></span></p>
                    </div>
                </div>
                
                <div class="row mt-3">
                    <div class="col-md-6">
                        <h6 class="fw-bold">Estado y Pago</h6>
                        <p><strong>Estado:</strong> <span id="detalle_estado" class="badge"></span></p>
                        <p><strong>Precio Total:</strong> S/ <span id="detalle_precio_total"></span></p>
                        <p><strong>Adelanto Requerido (50%):</strong> S/ <span id="detalle_adelanto"></span></p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="fw-bold">Información de Pago</h6>
                        <div id="detalle_info_pago">
                            <p class="text-muted">No hay información de pago registrada</p>
                        </div>
                    </div>
                </div>
                
                <div class="mt-3">
                    <h6 class="fw-bold">Información Adicional</h6>
                    <p id="detalle_info_adicional" class="border p-2 rounded bg-light"></p>
                </div>
                
                <div class="mt-3">
                    <h6 class="fw-bold">Detalle del Menú</h6>
                    <div id="detalle_menu" class="border p-2 rounded bg-light"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary btn-editar-desde-detalle">Editar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal para Cambiar Estado -->
<div class="modal fade" id="modalCambiarEstado" tabindex="-1" aria-labelledby="modalCambiarEstadoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalCambiarEstadoLabel">Cambiar Estado de la Reserva</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formCambiarEstado">
                    <input type="hidden" id="cambiar_estado_id_reserva" name="id_reserva">
                    
                    <div class="mb-3">
                        <label for="nuevo_estado" class="form-label">Nuevo Estado</label>
                        <select class="form-select" id="nuevo_estado" name="nuevo_estado" required>
                            <option value="Pendiente">Pendiente</option>
                            <option value="Confirmado">Confirmado</option>
                            <option value="Pagado">Pagado</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" id="btnGuardarCambioEstado" class="btn btn-primary">Guardar Cambio</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal para Asociar Pago -->
<div class="modal fade" id="modalAsociarPago" tabindex="-1" aria-labelledby="modalAsociarPagoLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalAsociarPagoLabel">Asociar Pago a Reserva</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-4">
                    <h6>Detalles de la Reserva</h6>
                    <p><strong>Cliente:</strong> <span id="asociar_nombre"></span></p>
                    <p><strong>Fecha:</strong> <span id="asociar_fecha"></span></p>
                    <p><strong>Total:</strong> S/ <span id="asociar_total"></span></p>
                    <p><strong>Adelanto Requerido (50%):</strong> S/ <span id="asociar_adelanto"></span></p>
                </div>
                
                <h6>Pagos Pendientes por Asociar</h6>
                <?php if (count($pagos_pendientes) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-sm table-hover" id="tablaPagosPendientes">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Teléfono</th>
                                <th>Fecha</th>
                                <th>Método</th>
                                <th>Monto</th>
                                <th>Seleccionar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pagos_pendientes as $pago): ?>
                            <tr>
                                <td><?php echo $pago['id_pago']; ?></td>
                                <td><?php echo htmlspecialchars($pago['telefono']); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($pago['fecha_pago'])); ?></td>
                                <td><?php echo htmlspecialchars($pago['metodo_pago']); ?></td>
                                <td>S/ <?php echo number_format($pago['monto'], 2); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary btn-seleccionar-pago" data-id="<?php echo $pago['id_pago']; ?>" data-monto="<?php echo $pago['monto']; ?>">
                                        Seleccionar
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    No hay pagos pendientes por asociar.
                </div>
                <?php endif; ?>
                
                <form id="formAsociarPago" class="mt-3">
                    <input type="hidden" id="asociar_id_reserva" name="id_reserva">
                    <input type="hidden" id="asociar_id_pago" name="id_pago">
                    
                    <div class="mb-3">
                        <label for="pago_seleccionado" class="form-label">Pago Seleccionado</label>
                        <input type="text" class="form-control" id="pago_seleccionado" readonly>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" id="btnAsociarPago" class="btn btn-primary" disabled>Asociar Pago</button>
            </div>
        </div>
    </div>
</div>

<!-- Enlazar archivos JavaScript -->
<script src="assets/js/admin-reservas.js"></script>

<?php
// Incluir el pie de página
include('includes/footer.php');
?>
