<?php
class ReservaControllers {
    private $con;
    
    public function __construct() {
        // Incluir archivo de conexión
        require_once(__DIR__ . '/../public/db.php');
        $this->con = $GLOBALS['con'];
    }
    
    /**
     * Obtiene todas las reservas
     */
    public function obtenerTodasReservas() {
        $sql = "SELECT r.id_reserva, u.nombre, u.telefono, u.email, r.fecha_reserva, r.hora_reserva, 
                r.cantidad_personas, r.tipo_menu, r.estado, r.total, r.info_adicional, r.detalle_menu
                FROM reservas r
                LEFT JOIN usuarios u ON r.id_usuario = u.id_usuario
                ORDER BY r.fecha_reserva DESC, r.hora_reserva ASC";
        
        $result = $this->con->query($sql);
        $reservas = [];
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $reservas[] = $row;
            }
        }
        
        return $reservas;
    }
    
    /**
     * Obtiene los detalles de una reserva específica
     */
    public function obtenerDetalleReserva($id_reserva) {
        $sql = "SELECT r.id_reserva, u.nombre, u.telefono, u.email, r.fecha_reserva, r.hora_reserva, 
                r.cantidad_personas, r.tipo_menu, r.estado, r.total, r.info_adicional, r.detalle_menu,
                p.id_pago, p.metodo_pago, p.numero_operacion, p.fecha_pago, p.monto
                FROM reservas r
                LEFT JOIN usuarios u ON r.id_usuario = u.id_usuario
                LEFT JOIN pagos p ON r.id_pago = p.id_pago
                WHERE r.id_reserva = ?";
        
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param("i", $id_reserva);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $reserva = $result->fetch_assoc();
            
            // Formatear fechas y horas
            $reserva['fecha_formateada'] = date('d/m/Y', strtotime($reserva['fecha_reserva']));
            $reserva['hora_formateada'] = date('H:i', strtotime($reserva['hora_reserva']));
            
            // Decodificar detalle del menú si existe
            if ($reserva['detalle_menu']) {
                $reserva['detalle_menu'] = json_decode($reserva['detalle_menu'], true);
            }
            
            // Formatear información de pago si existe
            if ($reserva['id_pago']) {
                $reserva['pago'] = [
                    'id_pago' => $reserva['id_pago'],
                    'metodo_pago' => $reserva['metodo_pago'],
                    'numero_operacion' => $reserva['numero_operacion'],
                    'fecha_pago' => $reserva['fecha_pago'],
                    'fecha_pago_formateada' => date('d/m/Y', strtotime($reserva['fecha_pago'])),
                    'monto' => $reserva['monto']
                ];
            } else {
                $reserva['pago'] = null;
            }
            
            // Eliminar campos duplicados
            unset($reserva['id_pago'], $reserva['metodo_pago'], $reserva['numero_operacion'], $reserva['fecha_pago'], $reserva['monto']);
            
            return $reserva;
        }
        
        return null;
    }
    
    /**
     * Obtiene pagos pendientes (no asociados a reservas)
     */
    public function obtenerPagosPendientes() {
        $sql = "SELECT p.id_pago, p.telefono, p.fecha_pago, p.metodo_pago, p.numero_operacion, p.monto
                FROM pagos p
                LEFT JOIN reservas r ON p.id_pago = r.id_pago
                WHERE r.id_reserva IS NULL
                ORDER BY p.fecha_pago DESC";
        
        $result = $this->con->query($sql);
        $pagos = [];
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $pagos[] = $row;
            }
        }
        
        return $pagos;
    }
    
    /**
     * Crea una nueva reserva
     */
    public function crearReserva($nombre, $telefono, $email, $fecha, $hora, $personas, $menu_tipo, $estado, $precio_total, $info_adicional) {
        // Primero verificar si existe el usuario o crear uno nuevo
        $id_usuario = $this->obtenerOCrearUsuario($nombre, $telefono, $email);
        
        // Crear la reserva
        $sql = "INSERT INTO reservas (id_usuario, fecha_reserva, hora_reserva, cantidad_personas, tipo_menu, estado, total, info_adicional) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param("issiisds", $id_usuario, $fecha, $hora, $personas, $menu_tipo, $estado, $precio_total, $info_adicional);
        
        $resultado = $stmt->execute();
        $stmt->close();
        
        return $resultado;
    }
    
    /**
     * Actualiza una reserva existente
     */
    public function actualizarReserva($id_reserva, $nombre, $telefono, $email, $fecha, $hora, $personas, $menu_tipo, $estado, $precio_total, $info_adicional) {
        // Primero verificar si existe el usuario o crear uno nuevo
        $id_usuario = $this->obtenerOCrearUsuario($nombre, $telefono, $email);
        
        // Actualizar la reserva
        $sql = "UPDATE reservas SET 
                id_usuario = ?, 
                fecha_reserva = ?, 
                hora_reserva = ?, 
                cantidad_personas = ?, 
                tipo_menu = ?, 
                estado = ?, 
                total = ?, 
                info_adicional = ? 
                WHERE id_reserva = ?";
        
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param("issiisdsi", $id_usuario, $fecha, $hora, $personas, $menu_tipo, $estado, $precio_total, $info_adicional, $id_reserva);
        
        $resultado = $stmt->execute();
        $stmt->close();
        
        return $resultado;
    }
    
    /**
     * Actualiza el estado de una reserva
     */
    public function actualizarEstadoReserva($id_reserva, $nuevo_estado) {
        $sql = "UPDATE reservas SET estado = ? WHERE id_reserva = ?";
        
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param("si", $nuevo_estado, $id_reserva);
        
        $resultado = $stmt->execute();
        $stmt->close();
        
        return $resultado;
    }
    
    /**
     * Asocia un pago a una reserva
     */
    public function asociarPagoReserva($id_reserva, $id_pago) {
        // Primero verificar que el pago existe y no está asociado a otra reserva
        $sql_check = "SELECT id_pago FROM pagos WHERE id_pago = ? AND id_pago NOT IN (SELECT id_pago FROM reservas WHERE id_pago IS NOT NULL)";
        $stmt_check = $this->con->prepare($sql_check);
        $stmt_check->bind_param("i", $id_pago);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        
        if ($result_check->num_rows === 0) {
            $stmt_check->close();
            return false; // El pago no existe o ya está asociado
        }
        
        $stmt_check->close();
        
        // Asociar el pago a la reserva
        $sql = "UPDATE reservas SET id_pago = ?, estado = 'Pagado' WHERE id_reserva = ?";
        
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param("
