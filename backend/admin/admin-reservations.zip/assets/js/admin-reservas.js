document.addEventListener("DOMContentLoaded", () => {
  // Variables globales
  let reservasData = []
  const $ = window.jQuery // Declare the $ variable
  const bootstrap = window.bootstrap // Declare the bootstrap variable

  // Inicializar la página
  inicializarPagina()

  // Función para inicializar la página
  function inicializarPagina() {
    // Cargar datos de reservas
    cargarDatosReservas()

    // Inicializar eventos
    inicializarEventos()

    // Inicializar cálculos automáticos
    inicializarCalculosAutomaticos()
  }

  // Función para cargar datos de reservas desde la tabla
  function cargarDatosReservas() {
    const filas = document.querySelectorAll("#tablaReservas tbody tr")
    reservasData = Array.from(filas).map((fila) => {
      const id = fila.getAttribute("data-id")
      const celdas = fila.querySelectorAll("td")

      return {
        id: id,
        nombre: celdas[1].textContent,
        telefono: celdas[2].textContent,
        fecha: celdas[3].textContent,
        hora: celdas[4].textContent,
        personas: celdas[5].textContent,
        menu_tipo: celdas[6].textContent,
        total: Number.parseFloat(celdas[7].textContent.replace("S/ ", "")),
        estado: celdas[8].querySelector(".badge").textContent.trim(),
      }
    })
  }

  // Función para inicializar eventos
  function inicializarEventos() {
    // Botones para ver detalles
    document.querySelectorAll(".btn-ver-detalles").forEach((btn) => {
      btn.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        mostrarDetallesReserva(id)
      })
    })

    // Botones para editar
    document.querySelectorAll(".btn-editar").forEach((btn) => {
      btn.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        cargarDatosEdicion(id)
      })
    })

    // Botón para editar desde la vista de detalles
    document.querySelector(".btn-editar-desde-detalle").addEventListener("click", () => {
      const id = document.querySelector("#detalle_id").value
      cargarDatosEdicion(id)
      $("#modalDetallesReserva").modal("hide")
    })

    // Botones para cambiar estado
    document.querySelectorAll(".btn-cambiar-estado").forEach((btn) => {
      btn.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        const estadoActual = this.getAttribute("data-estado")
        abrirModalCambiarEstado(id, estadoActual)
      })
    })

    // Botones para asociar pago
    document.querySelectorAll(".btn-asociar-pago").forEach((btn) => {
      btn.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        abrirModalAsociarPago(id)
      })
    })

    // Botón para guardar cambio de estado
    document.getElementById("btnGuardarCambioEstado").addEventListener("click", () => {
      guardarCambioEstado()
    })

    // Botones para seleccionar pago
    document.querySelectorAll(".btn-seleccionar-pago").forEach((btn) => {
      btn.addEventListener("click", function () {
        const idPago = this.getAttribute("data-id")
        const monto = this.getAttribute("data-monto")
        seleccionarPago(idPago, monto)
      })
    })

    // Botón para asociar pago
    document.getElementById("btnAsociarPago").addEventListener("click", () => {
      asociarPago()
    })

    // Botón para filtrar
    document.getElementById("btnFiltrar").addEventListener("click", () => {
      filtrarReservas()
    })

    // Botón para limpiar filtros
    document.getElementById("btnLimpiarFiltros").addEventListener("click", () => {
      limpiarFiltros()
    })

    // Calcular precio automáticamente al cambiar menú y personas
    document.getElementById("menu_tipo").addEventListener("change", calcularPrecioAutomatico)
    document.getElementById("personas").addEventListener("change", calcularPrecioAutomatico)
    document.getElementById("editar_menu_tipo").addEventListener("change", calcularPrecioAutomaticoEditar)
    document.getElementById("editar_personas").addEventListener("change", calcularPrecioAutomaticoEditar)
  }

  // Función para inicializar cálculos automáticos
  function inicializarCalculosAutomaticos() {
    // Calcular precio automáticamente al crear reserva
    calcularPrecioAutomatico()
  }

  // Función para calcular precio automáticamente en nueva reserva
  function calcularPrecioAutomatico() {
    const menuTipo = document.getElementById("menu_tipo").value
    const personas = Number.parseInt(document.getElementById("personas").value) || 1
    let precioBase = 0

    switch (menuTipo) {
      case "desayuno":
        precioBase = 9.0
        break
      case "almuerzo":
        precioBase = 14.5
        break
      case "cena":
        precioBase = 16.5
        break
    }

    const precioTotal = precioBase * personas
    document.getElementById("precio_total").value = precioTotal.toFixed(2)
  }

  // Función para calcular precio automáticamente en edición
  function calcularPrecioAutomaticoEditar() {
    const menuTipo = document.getElementById("editar_menu_tipo").value
    const personas = Number.parseInt(document.getElementById("editar_personas").value) || 1
    let precioBase = 0

    switch (menuTipo) {
      case "desayuno":
        precioBase = 9.0
        break
      case "almuerzo":
        precioBase = 14.5
        break
      case "cena":
        precioBase = 16.5
        break
    }

    const precioTotal = precioBase * personas
    document.getElementById("editar_precio_total").value = precioTotal.toFixed(2)
  }

  // Función para mostrar detalles de una reserva
  function mostrarDetallesReserva(id) {
    // Buscar la reserva en los datos cargados
    fetch(`obtener-detalle-reserva.php?id=${id}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          const reserva = data.reserva

          // Llenar los campos del modal
          document.getElementById("detalle_nombre").textContent = reserva.nombre
          document.getElementById("detalle_telefono").textContent = reserva.telefono
          document.getElementById("detalle_email").textContent = reserva.email || "No proporcionado"
          document.getElementById("detalle_fecha").textContent = reserva.fecha_formateada
          document.getElementById("detalle_hora").textContent = reserva.hora_formateada
          document.getElementById("detalle_personas").textContent = reserva.cantidad_personas
          document.getElementById("detalle_menu_tipo").textContent =
            reserva.tipo_menu.charAt(0).toUpperCase() + reserva.tipo_menu.slice(1)

          // Estado con clase de color
          const estadoElement = document.getElementById("detalle_estado")
          estadoElement.textContent = reserva.estado
          estadoElement.className = "badge"

          if (reserva.estado === "Pendiente") {
            estadoElement.classList.add("bg-warning")
          } else if (reserva.estado === "Confirmado") {
            estadoElement.classList.add("bg-info")
          } else if (reserva.estado === "Pagado") {
            estadoElement.classList.add("bg-success")
          }

          document.getElementById("detalle_precio_total").textContent = reserva.total.toFixed(2)
          document.getElementById("detalle_adelanto").textContent = (reserva.total * 0.5).toFixed(2)

          // Información adicional
          document.getElementById("detalle_info_adicional").textContent =
            reserva.info_adicional || "Sin información adicional"

          // Detalle del menú
          let menuHTML = ""
          if (reserva.detalle_menu) {
            menuHTML = `<ul class="list-unstyled mb-0">`
            for (const [key, value] of Object.entries(reserva.detalle_menu)) {
              if (value && value !== "no_incluir") {
                menuHTML += `<li><strong>${key}:</strong> ${value}</li>`
              }
            }
            menuHTML += `</ul>`
          } else {
            menuHTML = "No hay detalles específicos del menú"
          }
          document.getElementById("detalle_menu").innerHTML = menuHTML

          // Información de pago
          const infoPagoElement = document.getElementById("detalle_info_pago")
          if (reserva.pago) {
            infoPagoElement.innerHTML = `
                            <p><strong>Método:</strong> ${reserva.pago.metodo_pago}</p>
                            <p><strong>Número de operación:</strong> ${reserva.pago.numero_operacion}</p>
                            <p><strong>Fecha de pago:</strong> ${reserva.pago.fecha_pago_formateada}</p>
                            <p><strong>Monto:</strong> S/ ${reserva.pago.monto.toFixed(2)}</p>
                        `
          } else {
            infoPagoElement.innerHTML = `<p class="text-muted">No hay información de pago registrada</p>`
          }

          // Guardar ID para edición
          document.querySelector("#detalle_id").value = id

          // Mostrar el modal
          const modal = new bootstrap.Modal(document.getElementById("modalDetallesReserva"))
          modal.show()
        } else {
          alert("Error al cargar los detalles de la reserva")
        }
      })
      .catch((error) => {
        console.error("Error:", error)
        alert("Error al cargar los detalles de la reserva")
      })
  }

  // Función para cargar datos para edición
  function cargarDatosEdicion(id) {
    fetch(`obtener-detalle-reserva.php?id=${id}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          const reserva = data.reserva

          // Llenar los campos del formulario de edición
          document.getElementById("editar_id_reserva").value = reserva.id_reserva
          document.getElementById("editar_nombre").value = reserva.nombre
          document.getElementById("editar_telefono").value = reserva.telefono
          document.getElementById("editar_email").value = reserva.email || ""
          document.getElementById("editar_fecha").value = reserva.fecha_reserva
          document.getElementById("editar_hora").value = reserva.hora_reserva
          document.getElementById("editar_personas").value = reserva.cantidad_personas
          document.getElementById("editar_menu_tipo").value = reserva.tipo_menu
          document.getElementById("editar_estado").value = reserva.estado
          document.getElementById("editar_precio_total").value = reserva.total.toFixed(2)
          document.getElementById("editar_info_adicional").value = reserva.info_adicional || ""

          // Mostrar el modal
          const modal = new bootstrap.Modal(document.getElementById("modalEditarReserva"))
          modal.show()
        } else {
          alert("Error al cargar los datos para edición")
        }
      })
      .catch((error) => {
        console.error("Error:", error)
        alert("Error al cargar los datos para edición")
      })
  }

  // Función para abrir modal de cambio de estado
  function abrirModalCambiarEstado(id, estadoActual) {
    document.getElementById("cambiar_estado_id_reserva").value = id
    document.getElementById("nuevo_estado").value = estadoActual

    const modal = new bootstrap.Modal(document.getElementById("modalCambiarEstado"))
    modal.show()
  }

  // Función para guardar cambio de estado
  function guardarCambioEstado() {
    const id = document.getElementById("cambiar_estado_id_reserva").value
    const nuevoEstado = document.getElementById("nuevo_estado").value

    const formData = new FormData()
    formData.append("ajax_action", "cambiar_estado")
    formData.append("id_reserva", id)
    formData.append("nuevo_estado", nuevoEstado)

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          // Cerrar modal
          const modal = bootstrap.Modal.getInstance(document.getElementById("modalCambiarEstado"))
          modal.hide()

          // Actualizar la página
          window.location.reload()
        } else {
          alert("Error: " + data.message)
        }
      })
      .catch((error) => {
        console.error("Error:", error)
        alert("Error al cambiar el estado")
      })
  }

  // Función para abrir modal de asociar pago
  function abrirModalAsociarPago(id) {
    // Buscar la reserva en los datos cargados
    const reserva = reservasData.find((r) => r.id === id)

    if (reserva) {
      document.getElementById("asociar_id_reserva").value = id
      document.getElementById("asociar_nombre").textContent = reserva.nombre
      document.getElementById("asociar_fecha").textContent = reserva.fecha
      document.getElementById("asociar_total").textContent = reserva.total.toFixed(2)
      document.getElementById("asociar_adelanto").textContent = (reserva.total * 0.5).toFixed(2)

      // Limpiar selección previa
      document.getElementById("asociar_id_pago").value = ""
      document.getElementById("pago_seleccionado").value = ""
      document.getElementById("btnAsociarPago").disabled = true

      const modal = new bootstrap.Modal(document.getElementById("modalAsociarPago"))
      modal.show()
    } else {
      alert("Error: No se encontró la reserva")
    }
  }

  // Función para seleccionar un pago
  function seleccionarPago(idPago, monto) {
    document.getElementById("asociar_id_pago").value = idPago
    document.getElementById("pago_seleccionado").value = `Pago #${idPago} - S/ ${Number.parseFloat(monto).toFixed(2)}`
    document.getElementById("btnAsociarPago").disabled = false
  }

  // Función para asociar un pago a una reserva
  function asociarPago() {
    const idReserva = document.getElementById("asociar_id_reserva").value
    const idPago = document.getElementById("asociar_id_pago").value

    if (!idReserva || !idPago) {
      alert("Debe seleccionar una reserva y un pago")
      return
    }

    const formData = new FormData()
    formData.append("ajax_action", "asociar_pago")
    formData.append("id_reserva", idReserva)
    formData.append("id_pago", idPago)

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          // Cerrar modal
          const modal = bootstrap.Modal.getInstance(document.getElementById("modalAsociarPago"))
          modal.hide()

          // Actualizar la página
          window.location.reload()
        } else {
          alert("Error: " + data.message)
        }
      })
      .catch((error) => {
        console.error("Error:", error)
        alert("Error al asociar el pago")
      })
  }

  // Función para filtrar reservas
  function filtrarReservas() {
    const fecha = document.getElementById("filtroFecha").value
    const estado = document.getElementById("filtroEstado").value
    const telefono = document.getElementById("filtroTelefono").value

    const filas = document.querySelectorAll("#tablaReservas tbody tr")

    filas.forEach((fila) => {
      let mostrar = true
      const celdas = fila.querySelectorAll("td")

      // Filtrar por fecha
      if (fecha && celdas[3].textContent !== fecha) {
        mostrar = false
      }

      // Filtrar por estado
      if (estado && celdas[8].textContent.trim() !== estado) {
        mostrar = false
      }

      // Filtrar por teléfono
      if (telefono && !celdas[2].textContent.includes(telefono)) {
        mostrar = false
      }

      // Mostrar u ocultar fila
      fila.style.display = mostrar ? "" : "none"
    })
  }

  // Función para limpiar filtros
  function limpiarFiltros() {
    document.getElementById("filtroFecha").value = ""
    document.getElementById("filtroEstado").value = ""
    document.getElementById("filtroTelefono").value = ""

    // Mostrar todas las filas
    document.querySelectorAll("#tablaReservas tbody tr").forEach((fila) => {
      fila.style.display = ""
    })
  }
})
