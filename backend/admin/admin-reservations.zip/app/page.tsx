"use client"

import  from "../assets/js/admin-reservas"

export default function SyntheticV0PageForDeployment() {
  return < />
}